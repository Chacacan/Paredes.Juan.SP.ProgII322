
package Model;


import java.io.Serializable;
import java.util.Objects;
import util.CSVSerializable;

public class Criatura implements Comparable<Criatura>, Serializable, CSVSerializable {
    private static final long serialVersionUID = 1L;
    
    private final int id;
    private final String nombre;
    private final String origen;
    private final TipoCriatura tipo;

    public Criatura(int id, String nombre, String origen, TipoCriatura tipo) {
        this.id = id;
        this.nombre = nombre;
        this.origen = origen;
        this.tipo = tipo;

    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getOrigen() {
        return origen;
    }

    public TipoCriatura getTipo() {
        return tipo;
    }

    @Override
    public int compareTo(Criatura otra) {
        return Integer.compare(this.id, otra.id);
    }

    @Override
    public String toString() {
        return String.format("Criatura{id=%d, nombre='%s', origen='%s', tipo=%s}", 
                            id, nombre, origen, tipo);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Criatura criatura = (Criatura) o;
        return id == criatura.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toCSV() {
        return String.format("%d,%s,%s,%s", id, nombre, origen, tipo);
    }

    public static Criatura fromCSV(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 4) {
            throw new IllegalArgumentException("Formato CSV inválido");
        }
        try {
            int id = Integer.parseInt(partes[0]);
            String nombre = partes[1];
            String origen = partes[2];
            TipoCriatura tipo = TipoCriatura.valueOf(partes[3]);
            return new Criatura(id, nombre, origen, tipo);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("ID no es un número válido", e);
        }
    }
}