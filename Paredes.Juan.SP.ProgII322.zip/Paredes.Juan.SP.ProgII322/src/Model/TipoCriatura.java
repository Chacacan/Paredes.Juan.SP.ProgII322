
package Model;


public enum TipoCriatura {
    DEMOGORGON,
    DEMODOG,
    SHADOW_MONSTER,
    MIND_FLAYER_MINION,
    MURCIELAGO,
    OTRO
}
