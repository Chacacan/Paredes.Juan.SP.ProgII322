
package paredes.juan.sp.progii322;

import Model.Criatura;
import Model.TipoCriatura;
import java.io.IOException;
import java.util.Comparator;
import servicio.BestiarioUpsideDown;


public class ParedesJuanSPProgII322 {


    public static void main(String[] args) {
try {
            BestiarioUpsideDown<Criatura> bestiario = new BestiarioUpsideDown<>();

            bestiario.agregar(new Criatura(1, "Demogorgon", "Upside Down", TipoCriatura.DEMOGORGON));
            bestiario.agregar(new Criatura(2, "Demodog Juvenil", "Bosque de Hawkins", TipoCriatura.DEMODOG));
            bestiario.agregar(new Criatura(3, "Shadow Tendril", "Dimensión Principal", TipoCriatura.SHADOW_MONSTER));
            bestiario.agregar(new Criatura(4, "Mind Flayer Spawn", "Upside Down", TipoCriatura.MIND_FLAYER_MINION));
            bestiario.agregar(new Criatura(5, "Murciélago del Upside Down", "Cueva Oscura", TipoCriatura.MURCIELAGO));

            System.out.println("Criaturas:");
            // Lambda: mostrar cada criatura
            bestiario.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCriaturas tipo DEMODOG:");
            // Filtrar por tipo DEMODOG (Predicate)
            bestiario.filtrar(c -> c.getTipo() == TipoCriatura.DEMODOG)
                     .forEach(c -> System.out.println(c));

            System.out.println("\nCriaturas que contienen 'shadow':");
            // Filtrar por nombre que contenga "shadow" (case-insensitive)
            bestiario.filtrar(c -> c.getNombre().toLowerCase().contains("shadow"))
                     .forEach(c -> System.out.println(c));

            System.out.println("\nCriaturas ordenadas por ID:");
            // Orden natural (por id). Usamos la sobrecarga sin argumento.
            bestiario.ordenar();
            bestiario.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCriaturas ordenadas por nombre:");
            // Ordenar por nombre usando Comparator (lambda)
            bestiario.ordenar(Comparator.comparing(Criatura::getNombre));
            bestiario.paraCadaElemento(c -> System.out.println(c));

            // Guardar binario
            bestiario.guardarEnArchivo("src/data/criaturas.dat");

            BestiarioUpsideDown<Criatura> cargado = new BestiarioUpsideDown<>();
            cargado.cargarDesdeArchivo("src/data/criaturas.dat");

            System.out.println("\nCriaturas cargadas desde archivo binario:");
            cargado.paraCadaElemento(c -> System.out.println(c));

            // Guardar CSV
            bestiario.guardarEnCSV("src/data/criaturas.csv");

            // Cargar desde CSV usando Criatura::fromCSV
            cargado.cargarDesdeCSV("src/data/criaturas.csv", Criatura::fromCSV);

            System.out.println("\nCriaturas cargadas desde archivo CSV:");
            cargado.paraCadaElemento(c -> System.out.println(c));

        } catch (IOException ex) {
            System.err.println("Error: " + ex.getMessage());
        }
    }
  }
    

