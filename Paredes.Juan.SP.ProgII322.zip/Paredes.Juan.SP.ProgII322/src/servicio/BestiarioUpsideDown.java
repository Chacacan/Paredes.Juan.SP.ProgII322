
package servicio;


import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import util.CSVSerializable;
import java.util.function.Function;

public class BestiarioUpsideDown<T extends CSVSerializable & Serializable> {
    private final List<T> elementos;

    public BestiarioUpsideDown() {
        this.elementos = new ArrayList<>();
    }

    public void agregar(T elemento) {
        if (elemento == null) {
            throw new IllegalArgumentException("El elemento no puede ser nulo");
        }
        elementos.add(elemento);
    }

    public T obtener(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
        return elementos.get(indice);
    }

    public void eliminar(int indice) {
        if (indice < 0 || indice >= elementos.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
        elementos.remove(indice);
    }
    
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T criatura : elementos) {
            if (criterio.test(criatura)) {
                resultado.add(criatura);
            }
        }
        return resultado;
    }

    public void ordenar() {
        elementos.sort(null);
    }

    public void ordenar(Comparator<T> comparador) {
        elementos.sort(comparador);
    }

    public void paraCadaElemento(java.util.function.Consumer<T> accion) {
        elementos.forEach(accion);
    }

    public void guardarEnArchivo(String ruta) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(elementos);
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String ruta) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos.clear();
            elementos.addAll((List<T>) ois.readObject());
        }catch(IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }

    public void guardarEnCSV(String ruta){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                writer.write(elemento.toCSV());
                writer.newLine();
            }
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> parser) throws IOException {
        elementos.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (!linea.isEmpty()) {
                    elementos.add(parser.apply(linea));
                }
            }
        }
    }

    public int tamanio() {
        return elementos.size();
    }
    

}
