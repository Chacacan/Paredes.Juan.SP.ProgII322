
package util;


public interface CSVSerializable {
    String toCSV();
}
